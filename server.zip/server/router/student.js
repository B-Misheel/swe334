const express = require('express');
const { getStudents, getStudent, createStudent, deleteStudent, updateStudent } = require('../controller/student');
const router = express.Router();

// Define routes
router.route('/')
    .get(getStudents)        
    .post(createStudent);    

router.route('/:userid')
    .get(getStudent)         
    .put(updateStudent)      
    .delete(deleteStudent);  

module.exports = router;
