const Category = require('../model/category');
exports.getCategories = async (req, res, next)=> 
    {
    try{
        const category = await Category.find();

        res.status(200).json({
            success:true,
            data:category,
         })
    
    }
    catch(err){
        res.status(400).json({
            success:true,
            data:"error",
         })
    }

};

exports.updateCategory = (req, res, next)=>{
    res.status(200).json({
        success:false,
        data:`${req.params.id} -tai catergory zasah`,
    })
};

exports.deleteCategory =async (req, res, next)=>
    {
        try{
            const category = await Category.deleteOne(req.params.id);
            res.status(200).json({
                success:true,
                data:category,
             })
        
        }
        catch(err){
            res.status(400).json({
                success:true,
                data:"error",
             })
        }

    };   

    exports.createCategory = async (req, res, next)=>
        {
            try{
                const category = await Category.create(req.body);
    
                res.status(200).json({
                    success:true,
                    data:category,
                 })
            
            }
            catch(err){
                res.status(400).json({
                    success:true,
                    data:"error",
                 })
            }
    
        };

        exports.getCategory =async (req, res, next)=>
            {
                try{
                    const category = await Category.findById(req.params.id);
            
                    res.status(200).json({
                        success:true,
                        data:category,
                     })
                
                }
                catch(err){
                    res.status(400).json({
                        success:true,
                        data:"error",
                     })
                }
            };