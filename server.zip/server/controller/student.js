const Student = require('../model/student');

// Get all students
exports.getStudents = async (req, res, next) => {
    try {
        const students = await Student.find().select('-_id -__v');
        res.status(200).json({
            success: true,
            data: students,
        });
    } catch (err) {
        res.status(400).json({
            success: false,
            message: "Error fetching students",
            error: err.message,
        });
    }
};

// Get student by userid
exports.getStudent = async (req, res, next) => {
    try {
        const student = await Student.findOne({ userid: req.params.userid }).select('-_id -__v');
        if (!student) {
            return res.status(404).json({
                success: false,
                message: "Student not found",
            });
        }
        res.status(200).json({
            success: true,
            data: student,
        });
    } catch (err) {
        res.status(400).json({
            success: false,
            message: "Error fetching student",
            error: err.message,
        });
    }
};

// Create a new student
// Create a new student
exports.createStudent = async (req, res, next) => {
    try {
        const { userid, firstname, lastname, hobby, kurs } = req.body;

        // Dynamically assign program based on userid
        let program = "";

        if (userid.includes("b20fa")) {
            program = "undsen";
        } else if (userid.includes("b20ff")) {
            program = "hamtarsan";
        }
        else if (userid.includes("b21fa")) {
            program = "undsen";
        }
        else if (userid.includes("b21ff")) {
            program = "hamtarsan";
        }
        else if (userid.includes("b22fa")) {
            program = "undsen";
        }
        else if (userid.includes("b22ff")) {
            program = "hamtarsan";
        }
        else if (userid.includes("b23fa")) {
            program = "undsen";
        }
        else if (userid.includes("b23ff")) {
            program = "hamtarsan";
        }
        else if (userid.includes("b24fa")) {
            program = "undsen";
        }
        else if (userid.includes("b24ff")) {
            program = "hamtarsan";
        }
        else {
            program = "default";  // If no match, assign a default program
        }

        // Create the student with the dynamically assigned program
        const student = await Student.create({
            userid,
            firstname,
            lastname,
            hobby,
            kurs,
            program,  // Assign the program here
        });

        // Manually remove _id and __v from the response object
        const studentResponse = student.toObject();
        delete studentResponse._id;
        delete studentResponse.__v;

        res.status(200).json({
            success: true,
            data: studentResponse,  // Return the created student without _id and __v
        });
    } catch (err) {
        res.status(400).json({
            success: false,
            message: "Error creating student",
            error: err.message,
        });
    }
};

// Update student program based on userid
exports.updateStudent = async (req, res, next) => {
    try {
        const { userid } = req.params;  // Access userid from URL

        // Dynamically assign program based on userid
        let program = "";
        if (userid.includes("b20fa")) {
            program = "undsen";
        } else if (userid.includes("b20ff")) {
            program = "hamtarsan";
        }
        else if (userid.includes("b21fa")) {
            program = "undsen";
        }
        else if (userid.includes("b21ff")) {
            program = "hamtarsan";
        }
        else if (userid.includes("b22fa")) {
            program = "undsen";
        }
        else if (userid.includes("b22ff")) {
            program = "hamtarsan";
        }
        else if (userid.includes("b23fa")) {
            program = "undsen";
        }
        else if (userid.includes("b23ff")) {
            program = "hamtarsan";
        }
        else if (userid.includes("b24fa")) {
            program = "undsen";
        }
        else if (userid.includes("b24ff")) {
            program = "hamtarsan";
        }
        else {
            program = "default";  // If no match, assign a default program
        }

        // Find and update the student by userid
        const student = await Student.findOneAndUpdate(
            { userid: userid },  // Search by userid
            { program: program },  // Update program field
            { new: true }  // Return the updated student
        ).select('-_id -__v');

        // If the student is not found, send an error
        if (!student) {
            return res.status(404).json({
                success: false,
                message: "Student not found",
            });
        }

        // Send the updated student data as a response
        res.status(200).json({
            success: true,
            data: student,  // Return the updated student object
        });
    } catch (err) {
        res.status(400).json({
            success: false,
            message: "Error updating student",
            error: err.message,
        });
    }
};

// Delete student by userid
exports.deleteStudent = async (req, res, next) => {
    try {
        const student = await Student.findOneAndDelete({ userid: req.params.userid }).select('-_id -__v');

        if (!student) {
            return res.status(404).json({
                success: false,
                message: "Student not found",
            });
        }

        res.status(200).json({
            success: true,
            message: "Student deleted",
        });
    } catch (err) {
        res.status(400).json({
            success: false,
            message: "Error deleting student",
            error: err.message,
        });
    }
};
