const User = require('../model/user');
exports.getUsers= async (req, res, next)=>
{
    try{
        const use = await User.find();

        res.status(200).json({
            success:true,
            data:use,
        })
    
    }
    catch(err){
        res.status(400).json({
            success:true,
            data:"error",
        })
    }

};


exports.updateUser =(req, res, next)=>
    {
        res.status(200).json({
            success:false,
            data:`${req.params.id} -tai catergory zasah`,
        })
    };
exports.deleteUser =async (req, res, next)=>
    {
        try{
            const use = await User.deleteOne(req.params.id);
            res.status(200).json({
                success:true,
                data:use,
            })
        
        }
        catch(err){
            res.status(400).json({
                success:true,
                data:"error",
            })
        }

    };   

exports.createUser = async (req, res, next)=>
    {
        try{
            const use = await User.create(req.body);

            res.status(200).json({
                success:true,
                data:use,
            })
        
        }
        catch(err){
            res.status(400).json({
                success:true,
                data:"error",
            })
        }

    };   
exports.getUser =async (req, res, next)=>
    {
        try{
            const use = await User.findById(req.params.id);
    
            res.status(200).json({
                success:true,
                data:use,
            })
        
        }
        catch(err){
            res.status(400).json({
                success:true,
                data:"error",
            })
        }
    };