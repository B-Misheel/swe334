const Product = require('../model/product');
exports.getProducts = async (req, res, next)=> 
    {
    try{
        const product = await Product.find();

        res.status(200).json({
            success:true,
            data:product,
         })
    
    }
    catch(err){
        res.status(400).json({
            success:true,
            data:"error",
         })
    }

};

exports.updateProduct = (req, res, next)=>{
    res.status(200).json({
        success:false,
        data:`${req.params.id} -tai Product zasah`,
    })
};

exports.deleteProduct =async (req, res, next)=>
    {
        try{
            const product = await Product.deleteOne(req.params.id);
            res.status(200).json({
                success:true,
                data:product,
             })
        
        }
        catch(err){
            res.status(400).json({
                success:true,
                data:"error",
             })
        }

    };   

    exports.createProduct = async (req, res, next)=>
        {
            try{
                const product = await Product.create(req.body);
    
                res.status(200).json({
                    success:true,
                    data:product,
                 })
            
            }
            catch(err){
                res.status(400).json({
                    success:true,
                    data:"error",
                 })
            }
    
        };

        exports.getProduct =async (req, res, next)=>
            {
                try{
                    const product = await Product.findById(req.params.id);
            
                    res.status(200).json({
                        success:true,
                        data:product,
                     })
                
                }
                catch(err){
                    res.status(400).json({
                        success:true,
                        data:"error",
                     })
                }
            };