const express = require("express");
const dotenv = require('dotenv');
const connectDB = require('./config/db');

// Load env variables
dotenv.config({ path: "./config/config.env" });

const categoryRoute = require("./router/category");
const userRoute = require("./router/user");
const productRoute = require("./router/product");
const studentRoute = require("./router/student");

const app = express();
connectDB();

// Middleware to parse JSON body data
app.use(express.json());

app.use('/api/category', categoryRoute);
app.use('/api/user', userRoute);
app.use('/api/product', productRoute);
app.use('/api/student', studentRoute);

app.listen(process.env.PORT, () =>
    console.log(`Server is running on port ${process.env.PORT}`)
);
