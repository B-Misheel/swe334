const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    firstname: {
        type: String,
        required: [true, "Please provide a first name"],
        trim: true,
        maxlength: [50, "First name cannot exceed 50 characters"],
    },
    lastname: {
        type: String,
        required: [true, "Please provide a last name"],
        trim: true,
        maxlength: [50, "Last name cannot exceed 50 characters"],
    },
    userid: {
        type: Number,
        required: [true, "Please provide a user ID"],
        unique: true,
        trim: true,
    },
    phone: {
        type: Number,
        required: [true, "Please provide a phone number"],
        unique: true,
        match: [/^\d{10}$/, "Please enter a valid 10-digit phone number"], // Example for a 10-digit phone format
    },
    address: {
        type: String,
        required: [true, "Please provide an address"],
        maxlength: [100, "Address cannot exceed 100 characters"],
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model("User", UserSchema);