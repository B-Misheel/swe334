const mongoose = require('mongoose');
const CategorySchema = new mongoose.Schema(
    {
        name:{
            type:String, 
            required:[true, "please insert name"],
            unique:true,
            trim:true, 
            maxlength:[50, "max is 50"],

        },
        description:{
            type:String,
            required:[true, "must insert"],
            maxlength:[200, "max is 200"],
        },
        photo:{
            type:String,
            default:'no-photo.jpg'
        },
        avgrating:{
            type:Number,
            min:[3, 'min'],
            max:[10,'max']
        },
        createdAt:{
            type:Date,
            default:Date.now
        },
    }
) 
module.exports = mongoose.model("Category", CategorySchema);