const mongoose = require('mongoose');

// Define the schema for the Student model
const StudentSchema = new mongoose.Schema({
    userid: {
        type: String,
        required: [true, "Please provide a user ID"],
        unique: true,
        trim: true,
    },
    kurs: {
        type: Number,
        required: [true, "Please provide the year of study (1-6)"],
        trim: true,
    },
    firstname: {
        type: String,
        required: [true, "Please provide a first name"],
        trim: true,
        maxlength: [50, "First name cannot exceed 50 characters"],
    },
    lastname: {
        type: String,
        required: [true, "Please provide a last name"],
        trim: true,
        maxlength: [50, "Last name cannot exceed 50 characters"],
    },
    hobby: {
        type: String,
        required: [true, "Please provide a hobby"],
        maxlength: [100, "Hobby cannot exceed 100 characters"],
    },
    program: {
        type: String,
        maxlength: [100, "Program cannot exceed 100 characters"],
    },
});
StudentSchema.set('toJSON', {
    transform: function (doc, ret, options) {
        delete ret._id;
        delete ret.__v;
        return ret;
    }
});
module.exports = mongoose.model("Student", StudentSchema);
